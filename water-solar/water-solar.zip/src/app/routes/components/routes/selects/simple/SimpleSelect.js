import React from 'react';
import Input from '@material-ui/core/Input';

import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';

class SimpleSelect extends React.Component {
  state = {
    age: '',
    name: 'hai',
  };

  handleChange = name => event => {
    this.setState({[name]: event.target.value});
  };

  render() {
    return (
      <form className="row" autoComplete="off">
        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2">
            <InputLabel htmlFor="age-simple">Age</InputLabel>
            <Select
              value={this.state.age}
              onChange={this.handleChange('age')}
              input={<Input id="ageSimple1"/>}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>Ten</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2">
            <InputLabel htmlFor="age-helper">Age</InputLabel>
            <Select
              value={this.state.age}
              onChange={this.handleChange('age')}
              input={<Input id="age-helper"/>}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>Ten</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
            <FormHelperText>Some important helper text</FormHelperText>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2">
            <Select
              value={this.state.age}
              onChange={this.handleChange('age')}
              displayEmpty
              className="mt-3"
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>Ten</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
            <FormHelperText>Without label</FormHelperText>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2" disabled>
            <InputLabel htmlFor="name-disabled">Name</InputLabel>
            <Select
              value={this.state.name}
              onChange={this.handleChange('name')}
              input={<Input id="name-disabled"/>}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value="hai">Hai</MenuItem>
              <MenuItem value="olivier">Olivier</MenuItem>
              <MenuItem value="kevin">Kevin</MenuItem>
            </Select>
            <FormHelperText>Disabled</FormHelperText>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2" error>
            <InputLabel htmlFor="name-error">Name</InputLabel>
            <Select
              value={this.state.name}
              onChange={this.handleChange('name')}
              renderValue={value => `⚠️  - ${value}`}
              input={<Input id="name-error"/>}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value="hai">Hai</MenuItem>
              <MenuItem value="olivier">Olivier</MenuItem>
              <MenuItem value="kevin">Kevin</MenuItem>
            </Select>
            <FormHelperText>Error</FormHelperText>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2">
            <InputLabel htmlFor="name-input">Name</InputLabel>
            <Input id="nameInput1"/>
            <FormHelperText>Alignment with an input</FormHelperText>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2">
            <InputLabel htmlFor="name-readonly">Name</InputLabel>
            <Select
              value={this.state.name}
              onChange={this.handleChange('name')}
              input={<Input id="name-readonly" readOnly/>}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value="hai">Hai</MenuItem>
              <MenuItem value="olivier">Olivier</MenuItem>
              <MenuItem value="kevin">Kevin</MenuItem>
            </Select>
            <FormHelperText>Read only</FormHelperText>
          </FormControl>
        </div>

        <div className="col-lg-3 col-sm-6 col-12">
          <FormControl className="w-100 mb-2">
            <InputLabel htmlFor="age-simple">Age</InputLabel>
            <Select
              value={this.state.age}
              onChange={this.handleChange('age')}
              input={<Input id="ageSimple3"/>}
              autoWidth
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>Ten</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
            <FormHelperText>Auto width</FormHelperText>
          </FormControl>
        </div>
      </form>
    );
  }
}

export default SimpleSelect;