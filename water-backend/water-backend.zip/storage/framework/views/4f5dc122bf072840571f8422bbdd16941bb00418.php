<html>
<head></head>
<body style="background: black; color: white">
<h3>Client Name: <?php echo e($name); ?></h3>
<p>Email: <?php echo e($email); ?></p>
<p>Phone: <?php echo e($phone); ?></p>
<p>Company Name: <?php echo e($companyname); ?></p>
<p>City: <?php echo e($city); ?></p>
Company Logo has been Attached 
</body>
</html><?php /**PATH D:\Project\water\water-backend\resources\views/mail/sendMail.blade.php ENDPATH**/ ?>