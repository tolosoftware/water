<html>
<head></head>
<body style="background: black; color: white">
<h1><?php echo e($name); ?></h1>
<p><?php echo e($email); ?></p>
</body>
</html><?php /**PATH D:\Project\water\water-backend\resources\views/mail/sendMail.blade.php ENDPATH**/ ?>