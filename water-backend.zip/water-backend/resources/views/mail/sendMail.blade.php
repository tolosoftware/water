<html>
<head></head>
<body style="background: black; color: white">
<h3>Client Name: {{$name}}</h3>
<p>Email: {{$email}}</p>
<p>Phone: {{$phone}}</p>
<p>Company Name: {{$companyname}}</p>
<p>City: {{$city}}</p>
Company Logo has been Attached 
</body>
</html>
